# Run the two MATLAB L2O policies

The sweep uses Optimization Toolbox `linprog` and a separate tutorial
folder. An extracted ZIP or a Git checkout works. MATLAB verifies the
covariance and the tutorial functions used by the sweep against the pinned
revision and records their hashes in `environment.json`. If you need the
files, extract the [pinned tutorial ZIP](https://github.com/RangLiu0706/Clutter-Aware-ISAC-Tutorial/archive/0f864c45b4775fbe01789b313d81f22bebf65177.zip).

From any MATLAB working directory, select the folder containing `scripts`
and the tutorial root containing `data` and `function`. Start with two scenes
at one threshold to check the installation.

```matlab
bundle = uigetdir(pwd, 'Select the extracted bundle or letters-revision repository');
assert(ischar(bundle) && isfolder(fullfile(bundle,'scripts')), ...
    'Select the folder containing scripts.');
tutorial = uigetdir(pwd, 'Select the Clutter-Aware-ISAC-Tutorial folder');
assert(ischar(tutorial), 'Select the tutorial folder.');
cd(bundle)
addpath(fullfile(bundle,'scripts'),'-begin')
clear run_l2o_matlab_sweep run_matlab_sinr_sweep plot_matlab_sinr_sweep
preview = fullfile(bundle,"l2o-preview-"+string(datetime("now","Format","yyyyMMdd-HHmmss")));
T = run_l2o_matlab_sweep(tutorial,preview,Users=4,SINRdB=8,Seeds=11001:11002,Repeats=1);
```

If the preview reports errors, the console prints the first error for each
seed. The `K4/estimated/raw.csv` file lists every trial and its status.

Once the preview succeeds, launch the full sweep into a fresh folder.

```matlab
T = run_l2o_matlab_sweep(tutorial,fullfile(bundle,'l2o-thresholds'));
```

This uses the archived MATLAB sweep grid (4, 8 and 12 users, 0:4:20 dB,
seeds 11001–11008), the estimated design kernel, and six LP solves
(`Budget=[3 2]`). It times the two frozen Part E policies, reduced cost
and reduced cost plus envelope supervision. Both use the first physics
LP's dual features to propose atoms through a shared MLP. The following LP
assigns power.

Use `IncludeAnalytic=true` for an analytic-pricing reference using the
same counts. Use `DesignKernels=["estimated","perfect"]` to run both
archived design-kernel panels. Both settings report the true SCNR under
the ideal kernel.

Each `K<users>/<design-kernel>/` folder contains `raw.csv` with per-run
timings, `plots/scnr-vs-sinr.pdf`, and `plots/timing-vs-sinr.pdf`.
The root `summary.csv` combines all settings.
The `referenceMethod` column identifies the baseline for paired changes
and time ratios. In the two-policy sweep that baseline is the reduced-cost
policy. The policy training domain was 3–6 users and 6–14 dB. The
additional loads and thresholds in the archived grid are transfer tests.
